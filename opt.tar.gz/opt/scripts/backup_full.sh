#!/usr/bin/env bash
show_help(){
cat <<EOF
Uso: $(basename "$0") -o ORIGEN -d DESTINO
-o ORIGEN Directorio a respaldar.
-d Destino Directorio donde guardar el .tar.gz
-help Muestra esta ayuda.
EOF
}
ORIGEN=""
DESTINO=""
while [[ $# -gt 0 ]]; do
case "$1" in
-help) show_help; exit 0;;
-o) ORIGEN="$2"; shift 2;;
-d) DESTINO="$2"; shift 2;;
*)
echo "Opcion invalida: $1"; show_help; exit 1;;
esac
done

if [[ -z "$ORIGEN" || -z "DESTINO" ]]; then
echo "ERROR: Debes indicar -o y -d"
show_help
exit 1
fi

if [[ ! -d "$ORIGEN" ]]; then
echo "ERROR: Origen no encontrado: $ORIGEN"
exit 1
fi
if [[ ! -d "$DESTINO" ]]; then
echo "ERROR: Destino no encontrado: $DESTINO"
exit 1
fi

FECHA=$(date +%Y%m%d)
BASE=$(basename "$ORIGEN")
ARCHIVO="${BASE}_bkp_${FECHA}.tar.gz"

tar czf "${DESTINO}/${ARCHIVO}" -C "$(dirname "$ORIGEN")" "$BASE"
if [[ $? -eq 0 ]]; then
echo "Backup exitoso: ${DESTINO}/${ARCHIVO}"
exit 0
else
echo "ERROR creando backup"
exit 1
fi
